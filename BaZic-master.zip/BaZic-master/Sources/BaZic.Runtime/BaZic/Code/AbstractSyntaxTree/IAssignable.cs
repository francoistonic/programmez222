﻿namespace BaZic.Runtime.BaZic.Code.AbstractSyntaxTree
{
    /// <summary>
    /// Provides a way to identify whether a class from the syntax tree is an assignable value.
    /// </summary>
    public interface IAssignable
    {
    }
}
