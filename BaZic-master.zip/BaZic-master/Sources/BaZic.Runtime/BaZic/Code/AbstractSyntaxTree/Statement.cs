﻿using System;

namespace BaZic.Runtime.BaZic.Code.AbstractSyntaxTree
{
    /// <summary>
    /// Basic class that represents a statement in an algorithm
    /// </summary>
    [Serializable]
    public abstract class Statement : NodeObject
    {
    }
}
