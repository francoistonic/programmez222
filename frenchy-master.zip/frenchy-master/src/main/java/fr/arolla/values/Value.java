package fr.arolla.values;

public interface Value {
    Object value();
}
