<?php
  $array = [1, 2];
  list($a, &$b) = $array;

  // et aussi bien sur
  
  [$a, &$b] = $array;
?>