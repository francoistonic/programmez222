<?php
  $array = [1, 2];
  $a = $array[0];
  $b =& $array[1];
?>
