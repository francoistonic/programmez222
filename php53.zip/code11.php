<?php

$array = ['a' = > 1, 'b' => 2, 'c' => 3];

// solution 1 :
reset($array);
end($array);
$key = key($array);

// solution 2 :
$key = array_keys($array)[count($array) - 1];

// solution 3 :
foreach($array as $key => $value) {
	// Trop souvent utilisée
}

?>