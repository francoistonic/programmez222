<?php

// Ceci produit une erreur en PHP 7.3
define('FOO', 1, true);

echo FOO;

// Ceci produit une autre erreur en PHP 7.3
echo foo;

?>