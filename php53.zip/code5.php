<?php
$valeur = 'cookie';

setcookie("TestCookie", $value, time()+3600, "/~rasmus/", "example.com",);
setcookie("TestCookie", 
			$valeur, 
			time()+3600, 
			"/~rasmus/", 
			"example.com", 
			1,
			);

?>