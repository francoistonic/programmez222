CREATE TABLE vocabulary(word TEXT PRIMARY KEY, count INT DEFAULT 1);
INSERT INTO vocabulaire(word) VALUES('jovial')
  ON CONFLICT(word) DO UPDATE SET count=count+1;
