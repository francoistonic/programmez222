<?php

if (is_array($foo) || $foo instanceof Countable) {
    // $foo est comptable, ou \Countable
}

?>
