<?php

$array = [['c' => 1, 2], ['c' => 3, 4], ['c' => 5, 6]];
foreach ($array as list('c' => &$a, 1 => $b)) {
    $a = 7;
}
print_r($array);

?>