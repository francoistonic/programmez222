<?php

$animal = 'Corbeau';
// Heredoc
$x = <<<FRENCH
Maître $animal, sur un arbre perché,
FRENCH;

// Nowdoc
$x = <<<'FRENCH'
Maître $animal, sur un arbre perché,
FRENCH;

?>