<?php

$array = ['a' = > 1, 'b' => 2, 'c' => 3];

// solution 1 :
reset($array);
$key = key($array);

// solution 2 :
$key = array_keys($array)[0];

// solution 3 :
foreach($array as $key => $value) {
	break 1;
}

?>