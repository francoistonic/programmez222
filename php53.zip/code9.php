<?php

try {
	$read = json_decode($data, false, 512, JSON_THROW_ON_ERROR);
} catch (JsonException $e) {
   echo "les données entrantes ne sont pas valides\n";
}

?>