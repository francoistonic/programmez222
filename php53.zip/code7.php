<?php
  if (false === @preg_match($regex, null)) {
  	print "$regex is an invalid regex in pcre\n. Error : ".error_get_last()."\n";
  }
?>