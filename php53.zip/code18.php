<?php

print_r(hrtime(true));
print PHP_EOL;
print_r(hrtime());

?>