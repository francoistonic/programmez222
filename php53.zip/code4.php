<?php

function foo() {
	return <<<MESSAGE
	Voici le message
	MESSAGE;
}

print foo();
// affiche 'Returned Message'
?>