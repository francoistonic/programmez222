<?php

$variable = 'THINGS';
print strtolower(<<<ENGLISH
ALL THOSE $variable
ENGLISH);

?>