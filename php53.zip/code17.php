<?php

while ($foo) {
    switch ($bar) {
        case "baz":
            continue; // In PHP: se comporte comme "break;"
                      // In C:   se comporte comme "continue 2;"
    }
}

?>