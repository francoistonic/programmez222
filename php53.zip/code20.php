<?php

$foo = 'bar';

$array = compact('foo', 'foz');
// ['foo' => 'bar'];

?>
