<?php

$x = <<<FRANCAIS
Maître Corbeau, sur un arbre perché,
Tenait en son bec un fromage.
Maître Renard, par l'odeur alléché,
Lui tint à peu près ce langage:
Et bonjour, Monsieur du Corbeau,...
FRANCAIS;

?>