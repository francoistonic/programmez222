export function getApiPath() {
    return "http://localhost:10001"
}

export function getWsApiPath() {
    return "ws://localhost:10001"
}