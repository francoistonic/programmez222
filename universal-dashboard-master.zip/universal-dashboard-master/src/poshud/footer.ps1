New-UDFooter -Copyright "Ironman Software, LLC" -Links (
    New-UDLink -Url "https://ironmansoftware.com" -Text "Ironman Software, LLC" -Icon dashboard
)