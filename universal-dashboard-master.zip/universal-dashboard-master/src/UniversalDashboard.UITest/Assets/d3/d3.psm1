function New-UDCircos {
    New-UDElement -JavaScriptPath "$PSScriptRoot\public\d3.bundle.js" -ModuleName "UDD3" -ComponentName "UDCircos" 
}