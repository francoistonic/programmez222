createComponent({
    render: function() {
        return react.createElement('div', null, `Hello, ${this.props.toWhat}`);
    }
})